# sample-logger
Universal interceptor to intercept all HTTP request and response
