package org.mule.extension.internal;

import org.mule.metadata.api.model.MetadataType;
import org.mule.runtime.api.connection.ConnectionException;
import org.mule.runtime.api.metadata.MetadataContext;
import org.mule.runtime.api.metadata.MetadataResolvingException;
import org.mule.runtime.api.metadata.resolving.AttributesTypeResolver;
import org.mule.runtime.api.metadata.resolving.OutputTypeResolver;

public class OutputEntityResolver implements OutputTypeResolver<Object>, AttributesTypeResolver<Object> {
    public static final String PASSTHROUGH = "Passthrough";

    @Override
    public MetadataType getOutputType(MetadataContext context, Object o) throws MetadataResolvingException, ConnectionException {
        return context.getTypeLoader().load(o.getClass());
    }

    @Override
    public MetadataType getAttributesType(MetadataContext context, Object o) throws MetadataResolvingException, ConnectionException {
        return context.getTypeLoader().load(o.getClass());
    }

    @Override
    public String getResolverName() {
        return PASSTHROUGH;
    }

    @Override
    public String getCategoryName() {
        return PASSTHROUGH;
    }
}
