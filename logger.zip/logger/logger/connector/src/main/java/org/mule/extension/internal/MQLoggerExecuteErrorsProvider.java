package org.mule.extension.internal;

import org.mule.runtime.extension.api.annotation.error.ErrorTypeProvider;
import org.mule.runtime.extension.api.error.ErrorTypeDefinition;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class MQLoggerExecuteErrorsProvider implements ErrorTypeProvider {
    @Override
    public Set<ErrorTypeDefinition> getErrorTypes() {
        return new HashSet<>(Arrays.asList(MQLoggerError.MQ_ERROR));
    }
}
