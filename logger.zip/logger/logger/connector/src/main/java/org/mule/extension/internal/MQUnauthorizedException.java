package org.mule.extension.internal;

public class MQUnauthorizedException extends Exception {
    public MQUnauthorizedException() {
    }

    public MQUnauthorizedException(String message) {
        super(message);
    }

    public MQUnauthorizedException(String message, Throwable cause) {
        super(message, cause);
    }

    public MQUnauthorizedException(Throwable cause) {
        super(cause);
    }

    public MQUnauthorizedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
