package org.mule.extension.internal;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.mule.runtime.api.el.BindingContext;
import org.mule.runtime.api.metadata.DataType;
import org.mule.runtime.api.metadata.DataTypeBuilder;
import org.mule.runtime.api.metadata.MediaType;
import org.mule.runtime.api.metadata.TypedValue;
import org.mule.runtime.api.scheduler.SchedulerService;
import org.mule.runtime.core.api.el.ExpressionManager;
import org.mule.runtime.core.api.util.IOUtils;
import org.mule.runtime.extension.api.annotation.error.Throws;
import org.mule.runtime.extension.api.annotation.metadata.OutputResolver;
import org.mule.runtime.extension.api.annotation.param.Optional;
import org.mule.runtime.extension.api.exception.ModuleException;
import org.mule.runtime.extension.api.runtime.operation.Result;
import org.mule.runtime.extension.api.runtime.process.CompletionCallback;
import org.mule.runtime.extension.api.runtime.route.Chain;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.UUID;
import java.util.concurrent.TimeUnit;


/**
 * This class is a container for operations, every public method in this class will be taken as an extension operation.
 */
public class MQLoggerOperations {
    private static final Logger logger = LoggerFactory.getLogger(MQLoggerOperations.class);
    @Inject
    private ExpressionManager expressionManager;
    private CloseableHttpClient httpClient;
    private String bearerToken;

    @Inject
    private SchedulerService schedulerService;
    private PoolingHttpClientConnectionManager httpConPoolManager;
    private Integer curMaxHttpCon;

    public MQLoggerOperations() {
    }

    /**
     * Example of a simple operation that receives a string parameter and returns a new string message that will be set on the payload.
     */
    @OutputResolver(output = OutputEntityResolver.class)
    @Throws(MQLoggerExecuteErrorsProvider.class)
    public Object log(@Optional(defaultValue = "#[payload]") Object payload,
                      @Optional(defaultValue = "#[attributes]") Object attributes) {
        return payload;
    }

    /**
     * Log the HTTP payload by sending it to an MQ queue
     *
     * @param operations operations chain
     * @param callback   callback
     * @param payload    Payload
     * @param attributes Attributes
     */
    @SuppressWarnings("unchecked")
    @OutputResolver(output = OutputEntityResolver.class)
    @Throws(MQLoggerExecuteErrorsProvider.class)
    public void logRequestResponse(Chain operations,
                                   CompletionCallback<Object, Object> callback,
                                   @Optional(defaultValue = "https://mq-us-east-1.anypoint.mulesoft.com/api/v1") String mqClientUrl,
                                   @Optional(defaultValue = "${mqlog.client.id}") String mqClientId,
                                   @Optional(defaultValue = "${mqlog.client.secret}") String mqClientSecret,
                                   @Optional(defaultValue = "${mqlog.org}") String mqOrganization,
                                   @Optional(defaultValue = "${mqlog.env}") String mqEnvironment,
                                   @Optional(defaultValue = "${mqlog.dest}") String mqDestination,
                                   @Optional(defaultValue = "#[payload]") TypedValue<Object> payload,
                                   @Optional(defaultValue = "#[attributes]") TypedValue<Object> attributes,
                                   @Optional(defaultValue = "false") boolean forceDebug,
                                   @Optional(defaultValue = "true") boolean sendMQAsync,
                                   @Optional(defaultValue = "false") boolean sendMQAfterCallback,
                                   @Optional(defaultValue = "500") int maxHttpCon
    ) {
        long p1Start = System.currentTimeMillis();
        long mainStart = System.currentTimeMillis();

        log(forceDebug, "START >>> Logging Request Response");
        if (payload.getValue() instanceof InputStream) {
            // this is required to ensure the stream doesn't get read by dataweave
            payload = new TypedValue<>(IOUtils.toByteArray((InputStream) payload.getValue()), payload.getDataType());
        }
        TypedValue<Object> finalPayload = payload;

        // don'tt async here
        // THREAD 1 ENDS HERE
        final long p1 = System.currentTimeMillis() - p1Start;
        final long p2Start = System.currentTimeMillis();
        operations.process( // DOES NOT BLOCK
                result -> {
                    long p2 = System.currentTimeMillis() - p2Start;
                    // THREAD 2
                    // async here
                    long p3Start = System.currentTimeMillis();
                    logger.info("_message=\"Received Request\"");
                    if (result.getOutput() instanceof InputStream) {
                        // this is required to ensure the stream doesn't get read by dataweave
                        Result.Builder builder = result.copy().output(IOUtils.toByteArray((InputStream) result.getOutput()));
                        if (result.getMediaType().isPresent()) {
                            Object mediaType = result.getMediaType().get();
                            builder.mediaType((MediaType) mediaType);
                        }
                        result = builder.build();
                        logger.info("_message=\"Building Request Payload\"");
                    }
                    String json = null;
                    try {
                        //I couldn't hear you need to reconnect
                        logger.info("_message=\"Building Success Response Payload\"");
                        // START - record how long this takes maybe it's CPU intensive but I don't think so ?
                        // CPU COST ***MAYBE*** CAN BE REPLACED WITH "WORK" . either by not using dataweave,
                        // or maybe "cheating/hacking" through reflection to cache the dataweave expression.
                        long start = System.currentTimeMillis();
                        json = expressionManager.evaluate("#[output application/json --- { request: { payload: payload, attributes: attributes }, response: { payload: rpayload, attributes: rattributes }}]",
                                getBindingContext(finalPayload, attributes, result, null)).getValue().toString();
                        long duration = System.currentTimeMillis() - start;

                        logger.info("################################################### Duration for API resonse: " + duration);
                        // log duration
                        // END
                    } catch (Throwable e) {
                        logger.error("Unable to send mq log", e);
                    }
                    long p3 = System.currentTimeMillis() - p3Start;
                    if (!sendMQAfterCallback) {
                        sendLog(json, mqClientUrl, mqOrganization, mqEnvironment, mqDestination, mqClientId, mqClientSecret, forceDebug, sendMQAsync, maxHttpCon);
                    }
                    logger.info("TIMING: p1=" + p1 + "  p2=" + p2 + "  p3=" + p3);
                    try {
                        callback.success(result); // DOES NOT BLOCK only takes 0.0001ms
                    } catch (Throwable e) {
                        logger.error("GOT ERROR : " + e.getMessage(), e);
                    }
                    if (sendMQAfterCallback) {
                        sendLog(json, mqClientUrl, mqOrganization, mqEnvironment, mqDestination, mqClientId, mqClientSecret, forceDebug, sendMQAsync, maxHttpCon);
                    }
                },
                (error, previous) -> {
                    String json = null;
                    try {
                        logger.info("_message=\"Building Error Response Payload\"");
                        json = expressionManager.evaluate("#[output application/json --- { request: { payload: payload, attributes: attributes }, response: { payload: rpayload, attributes: rattributes } , error: { class: errorClass, message: errorMessage, stackTrace: errorStackTrace } }]",
                                getBindingContext(finalPayload, attributes, previous, error)).getValue().toString();
                    } catch (Throwable e) {
                        logger.error("Unable to send mq log", e);
                    }
                    logger.error("ERROR: " + error.getClass().getName() + " = " + error);
                    callback.error(error);
                    sendLog(json, mqClientUrl, mqOrganization, mqEnvironment, mqDestination, mqClientId, mqClientSecret, forceDebug, sendMQAsync, maxHttpCon);
                });
        long mainEnd = mainStart - System.currentTimeMillis();
    }

    /**
     * Log message as info with a marker prefix if forceDebug is true, or as info without marker prefix if set to false
     *
     * @param forceDebug If debug logging should be done
     * @param message    Message to log
     */
    private void log(boolean forceDebug, String message) {
        if (forceDebug) {
            logger.info("*** MQLogger: " + message);
        } else {
            logger.debug(message);
        }
    }

    private void sendLog(String json, String mqUrl, String mqOrganization, String mqEnvironment, String mqDestination,
                         String mqClientId, String mqClientSecret, boolean forceDebug, boolean sendMQAsync, int maxHttpCon) {
        if (sendMQAsync) {
            //Async block - this will use mule ioScheduler
            schedulerService.ioScheduler().schedule(new Runnable() {
                @Override
                public void run() {
                    doSendLog(mqClientId, mqClientSecret, json, mqUrl, mqOrganization, mqEnvironment, mqDestination, forceDebug, maxHttpCon);
                }
            }, 0, TimeUnit.MILLISECONDS);
        } else {
            doSendLog(mqClientId, mqClientSecret, json, mqUrl, mqOrganization, mqEnvironment, mqDestination, forceDebug, maxHttpCon);
        }
    }

    private void doSendLog(String mqClientId, String mqClientSecret, String json, String mqUrl, String mqOrganization, String mqEnvironment, String mqDestination, boolean forceDebug, int maxHttpCon) {
        long mq1Start = System.currentTimeMillis();
        boolean mqAuth = false;
        long mq1 = 0;
        long mq2 = 0;
        long mq3 = 0;
        long mq4 = 0;
        long mqHttp = 0;
        try {
            if (bearerToken == null) {
                refreshBearerToken(mqClientId, mqClientSecret);
                mqAuth = true;
            }
            mq1 = System.currentTimeMillis() - mq1Start;
            long mq2Start = System.currentTimeMillis();
            String mqMsg = expressionManager.evaluate("#[output application/json --- { properties : { contentType : \"application/json; charset=UTF-8\"}, lockTtl : 86400000, body: json}]",
                    BindingContext.builder().addBinding("json", new TypedValue<>(json, DataType.STRING)).build()).getValue().toString();
            mq2 = System.currentTimeMillis() - mq2Start;
            try {
                long mq3Start = System.currentTimeMillis();
                mqHttp = sendMQMessage(mqUrl, mqOrganization, mqEnvironment, mqDestination, mqMsg, forceDebug, maxHttpCon);
                mq3 = System.currentTimeMillis() - mq3Start;
            } catch (MQUnauthorizedException e) {
                logger.info("Unauthorized refreshing token, exception "+e.getMessage());
                long mq4Start = System.currentTimeMillis();
                refreshBearerToken(mqClientId, mqClientSecret);
                mqAuth = true;
                mqHttp = sendMQMessage(mqUrl, mqOrganization, mqEnvironment, mqDestination, mqMsg, forceDebug, maxHttpCon);
                mq4 = System.currentTimeMillis() - mq4Start;
            }
        } catch (Exception e) {
            logger.error("Failed to send logging mq message: " + e.getMessage(), e);
        } finally {
            //logger.info("MQTIMING: total=" + (System.currentTimeMillis() - mq1Start) + "  mq1=" + mq1 + "  mq2=" + mq2 + "  mq3=" + mq3 + " pool=" + httpConPoolManager.getTotalStats());
        }
    }

    private long sendMQMessage(String mqUrl, String mqOrganization, String mqEnvironment, String mqDestination, String mqMsg, boolean forceDebug, int maxHttpCon) throws MQUnauthorizedException, IOException {
        logger.info("Sending message to Anypoint MQ");
        long start = System.currentTimeMillis();
        try {
            String messageId = UUID.randomUUID().toString();
            HttpPut method = new HttpPut(mqUrl + "/organizations/" + mqOrganization + "/environments/" + mqEnvironment + "/destinations/" + mqDestination + "/messages/" + messageId);
            method.addHeader("Authorization", "bearer " + bearerToken);
            method.setEntity(new StringEntity(mqMsg, ContentType.APPLICATION_JSON));

            CloseableHttpClient hc;
            if (maxHttpCon < 1) {
                closeHttpClient();
                hc = HttpClients.createMinimal(new BasicHttpClientConnectionManager());
            } else {
                if (httpClient == null || curMaxHttpCon == null || curMaxHttpCon != maxHttpCon) {
                    closeHttpClient();
                    httpConPoolManager = new PoolingHttpClientConnectionManager();
                    httpConPoolManager.setDefaultMaxPerRoute(maxHttpCon);
                    httpConPoolManager.setMaxTotal(maxHttpCon);
                    curMaxHttpCon = maxHttpCon;
                    httpClient = HttpClients.createMinimal(httpConPoolManager);
                }
                hc = httpClient;
            }
            try {
                try (CloseableHttpResponse response = httpClient.execute(method)) {
                    int statusCode = response.getStatusLine().getStatusCode();
                    if (response.getEntity() != null) {
                        log(forceDebug, "mq response: " + IOUtils.toString(response.getEntity().getContent()));
                    }
                    if (statusCode == 401) {
                        throw new MQUnauthorizedException();
                    } else if (response.getStatusLine().getStatusCode() != 201) {
                        logger.error("Sending MQ message didn't return status code 201: " + response.getStatusLine());
                    }
                }
            } finally {
                if (maxHttpCon < 1) {
                    hc.close();
                }
            }
        } finally {
            logger.info("**** SENDMQ: " + (System.currentTimeMillis() - start));
        }
        return System.currentTimeMillis() - start;
    }

    private void closeHttpClient() {
        if( httpClient != null ) {
            try {
                httpClient.close();
            } catch (Exception e) {
                //
            }
            httpClient = null;
        }
        if( httpConPoolManager != null ) {
            try {
                httpConPoolManager.close();
            } catch (Exception e) {
                //
            }
            httpConPoolManager = null;
        }
    }

    private static BindingContext getBindingContext(@Optional(defaultValue = "#[payload]") TypedValue<Object> payload, @Optional(defaultValue = "#[attributes]") TypedValue<Object> attributes, Result result, Throwable error) {
        BindingContext.Builder builder = BindingContext.builder()
                .addBinding("payload", payload)
                .addBinding("attributes", attributes)
                .addBinding("rpayload", getTypeValue(result.getOutput(), result.getMediaType()))
                .addBinding("rattributes", getTypeValue(result.getAttributes(), result.getAttributesMediaType()));
        if (error != null) {
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            error.printStackTrace(new PrintStream(buf));
            String stackTrace = new String(buf.toByteArray());
            builder = builder.addBinding("errorClass", new TypedValue<>(error.getClass().getName(), DataType.STRING))
                    .addBinding("errorMessage", new TypedValue<>(error.getMessage(), DataType.STRING))
                    .addBinding("errorStackTrace", new TypedValue<>(stackTrace, DataType.STRING));
        }
        return builder.build();
    }

    @SuppressWarnings("OptionalUsedAsFieldOrParameterType")
    private static TypedValue getTypeValue(Object object, java.util.Optional mediaType) {
        if (object instanceof java.util.Optional) {
            if (((java.util.Optional) object).isPresent()) {
                object = ((java.util.Optional) object).get();
            } else {
                object = null;
            }
        }
        return new TypedValue<>(object, getDataType(object, mediaType));
    }

    @SuppressWarnings("OptionalUsedAsFieldOrParameterType")
    private static DataType getDataType(Object object, java.util.Optional mt) {
        if (mt.isPresent()) {
            DataTypeBuilder builder = DataType.builder();
            if (object != null) {
                return builder.type(object.getClass()).mediaType((MediaType) mt.get()).build();
            } else {
                return builder.mediaType((MediaType) mt.get()).build();
            }
        } else {
            return DataType.fromObject(object);
        }
    }

    private void refreshBearerToken(String mqClientId, String mqClientSecret) {
        CloseableHttpResponse response = null;
        try {
            logger.info("Refreshing token 123...");
            if (httpClient == null || curMaxHttpCon == null || curMaxHttpCon != 500) {
                closeHttpClient();
                httpConPoolManager = new PoolingHttpClientConnectionManager();
                httpConPoolManager.setDefaultMaxPerRoute(500);
                httpConPoolManager.setMaxTotal(500);
                curMaxHttpCon = 500;
                httpClient = HttpClients.createMinimal(httpConPoolManager);
            }
            HttpPost method = new HttpPost("https://mq-us-east-1.anypoint.mulesoft.com/api/v1/authorize");
            method.setEntity(new StringEntity("client_id=" + mqClientId + "&client_secret=" + mqClientSecret + "&grant_type=client_credentials", ContentType.parse("application/x-www-form-urlencoded")));
            logger.info("HTTP Client: "+httpClient.toString()+" method: "+method.toString());
            response = httpClient.execute(method);
            logger.info("Token is refreshed..."+response.getStatusLine().getStatusCode());
            if (response.getStatusLine().getStatusCode() != 200) {
                logger.info("Not 200 response "+response.getStatusLine().getStatusCode());
                throw new ModuleException("Failed to retrieve bearer token, got status code: " + response.getStatusLine(),
                        MQLoggerError.MQ_ERROR);
            }
            if (response.getEntity() != null) {
                logger.info("Response after token refresh "+response.getEntity());
                TypedValue<?> parseResult = expressionManager.evaluate("#[output application/java --- j.access_token]", BindingContext.builder().addBinding("j", new TypedValue<>(response.getEntity().getContent(), DataType.JSON_STRING)).build());
                bearerToken = (String) parseResult.getValue();
            } else {
                logger.info("Authorization did not return any data "+response.getEntity());
                throw new ModuleException("authorize didn't return any data", MQLoggerError.MQ_ERROR);
            }
        } catch (IOException e) {
            logger.info("Error occured while refreshing token, exception "+e.getMessage());
            throw new ModuleException(MQLoggerError.MQ_ERROR, e);
        } finally {
            if (response != null) {
                try {
                    closeHttpClient();
                    response.close();
                } catch (IOException e) {
                    logger.info("Error occured while closing response, exception "+e.getMessage());
                }
            }
        }
    }
}
