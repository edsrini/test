package org.mule.extension.internal;

import org.mule.runtime.extension.api.error.ErrorTypeDefinition;
import org.mule.runtime.extension.api.error.MuleErrors;

import java.util.Optional;

public enum MQLoggerError implements ErrorTypeDefinition<MQLoggerError> {
    MQ_ERROR(MuleErrors.CONNECTIVITY);
    private ErrorTypeDefinition<? extends Enum<?>> parent;

    MQLoggerError(ErrorTypeDefinition<? extends Enum<?>> parent) {
        this.parent = parent;
    }

    MQLoggerError() {
    }

    @Override
    public Optional<ErrorTypeDefinition<? extends Enum<?>>> getParent() {
        return Optional.ofNullable(parent);
    }
}
