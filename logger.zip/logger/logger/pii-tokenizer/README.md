# Pii-tokenizer Extension

Add description ...


...


...


Add this dependency to your application pom.xml

```
<groupId>com.sample</groupId>
<artifactId>pii-tokenizer</artifactId>
<version>1.0.0</version>
```
