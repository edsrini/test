package com.sample.piitokenizer.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class TokenizationRule {
    private final List<TokenizationRuleMatcher> matchers = new ArrayList<>();
    private final List<TokenizationRulePath> paths = new ArrayList<>();

    public TokenizationRule() {
    }

    public TokenizationRule(TokenizationRuleMatcher ruleMatcher, List<TokenizationRulePath> paths) {
        matchers.add(ruleMatcher);
        this.paths.addAll(paths);
    }

    public TokenizationRule(TokenizationRuleMatcher ruleMatcher, TokenizationRulePath... paths) {
        this(ruleMatcher, Arrays.asList(paths));
    }

    public boolean matches(JsonNode node) {
        for (TokenizationRuleMatcher matcher : matchers) {
            if( ! matcher.match(node) ) {
                return false;
            }
        }
        return true;
    }

    @JsonProperty
    public List<TokenizationRuleMatcher> getMatchers() {
        return matchers;
    }

    @JsonProperty
    public List<TokenizationRulePath> getPaths() {
        return paths;
    }

    public void setPaths(List<TokenizationRulePath> paths) {
        this.paths.clear();
        this.paths.addAll(paths);
    }

    public static List<TokenizationRule> createList(TokenizationRuleMatcher ruleMatcher, TokenizationRulePath... paths) {
        return Collections.singletonList(new TokenizationRule(ruleMatcher,paths));
    }
}
