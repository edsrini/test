package com.sample.piitokenizer.internal;


import com.sample.piitokenizer.api.TokenizationRulePath;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.mule.runtime.core.api.util.IOUtils;
import org.mule.weave.v2.utils.StringEscapeHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * This class represents an extension connection just as example (there is no real connection with anything here c:).
 */
public final class PIITokenizerConnection {
    private static final Logger logger = LoggerFactory.getLogger(PIITokenizerConnection.class);
    private final String url;
    private final String username;
    private final String password;
    private final CloseableHttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final String authHeader;

    public PIITokenizerConnection(String url, String username, String password) {
        this.url = url;
        this.username = username;
        this.password = password;
        httpClient = HttpClientBuilder.create().build();
        String auth = username + ":" + password;
        objectMapper = new ObjectMapper();
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.ISO_8859_1));
        authHeader = "Basic " + new String(encodedAuth);
    }

    public String tokenize(TokenizationRulePath path, String value, boolean tokenize) throws IOException {
        if(value == null || value.isEmpty()){
            return "";
        }
        if(path.getTemplate().indexOf("internalImage") >= 0){
            logger.info("_message= SUPPRESSING IMAGE AS THE PATH IS IMAGE TEMPLATE");
            return "************";
        }
        String newValue = value.replaceAll("(\\r\\n|\\n|\\r)", " ");

        HashMap<String, String> req = new HashMap<>();
        req.put("tokengroup", path.getGroup());
        req.put("tokentemplate", path.getTemplate());
        req.put(tokenize ? "data" : "token", newValue);
        HttpPost request = new HttpPost(url + (tokenize ? "tokenize" : "detokenize"));
        request.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
        request.setEntity(new StringEntity(objectMapper.writeValueAsString(req)));
        CloseableHttpResponse response = httpClient.execute(request);
        if (response.getStatusLine().getStatusCode() != 200) {
            throw new IOException("Tokenization operation threw error code " + response.getStatusLine());
        }
        if (response.getEntity() == null || response.getEntity().getContent() == null) {
            throw new IOException("Tokenization operation didn't return an entity");
        }
        String json = IOUtils.toString(response.getEntity().getContent());
        Map r = objectMapper.readValue(json, Map.class);

        if (!r.get("status").equals("Succeed")) {
            if(r.get("reason").toString().indexOf("not enough input characters") >= 0
                    || r.get("reason").toString().indexOf("data exceeds 128 KBytes") >= 0){
                return "######";
            }
            throw new IOException("Tokenization operation didn't succeed: " + json);
        }
        return (String) r.get(tokenize ? "token" : "data");
    }

    public BigDecimal tokenize(TokenizationRulePath rule, BigDecimal value, boolean tokenize) throws IOException {
        return new BigDecimal(tokenize(rule, value.toPlainString(), tokenize));
    }

    public String getId() {
        return url;
    }

    public void invalidate() {
    }
}
